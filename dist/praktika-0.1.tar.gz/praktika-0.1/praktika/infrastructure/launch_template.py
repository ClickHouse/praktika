from ._utils import aws_client
import base64
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


class LaunchTemplate:

    @dataclass
    class Config:
        # Launch Template name
        name: str
        region: str = ""

        # Mandatory runner identification fields
        praktika_resource_tag: str = (
            ""  # Praktika resource tag (e.g., "mac") - tagged as "praktika_resource_tag"
        )
        runner_type: str = (
            ""  # GitHub runner type (e.g., "arm_macos_small") - tagged as "github:runner-type"
        )

        # High-level fields (optional). If `data` is provided, it is used as-is.
        image_id: str = ""
        image_builder_pipeline_name: str = ""
        instance_type: str = ""
        # If set, will be base64-encoded and applied as LaunchTemplateData.UserData
        user_data: str = ""
        security_group_ids: List[str] = field(default_factory=list)
        # Resolved to IDs at deploy time by looking up SG names in the VPC
        security_group_names: List[str] = field(default_factory=list)
        iam_instance_profile_name: str = ""
        tenancy: str = ""  # e.g. "host"
        host_id: str = ""

        # Block device mappings (passed through as LaunchTemplateData.BlockDeviceMappings).
        # Example: [{"DeviceName": "/dev/xvda",
        #            "Ebs": {"VolumeSize": 30, "VolumeType": "gp3",
        #                    "DeleteOnTermination": True}}]
        block_device_mappings: List[Dict[str, Any]] = field(default_factory=list)

        # Raw launch template data (passed directly to EC2 API as LaunchTemplateData)
        data: Dict[str, Any] = field(default_factory=dict)

        # If set, update will create a new version; if False, existing LT must not exist
        create_new_version: bool = True

        # If True, after creating a new version, automatically set it as the default version.
        set_default_version_to_latest: bool = False

        # Extra fetched/derived properties
        ext: Dict[str, Any] = field(default_factory=dict)

        def fetch(self):
            """
            Fetch Launch Template configuration from AWS and store in ext.

            Raises:
                Exception: If launch template does not exist or AWS API call fails
            """
            import boto3

            ec2 = aws_client("ec2", self.region, self.name)

            resp = ec2.describe_launch_templates(LaunchTemplateNames=[self.name])
            lts = resp.get("LaunchTemplates", [])
            if not lts:
                raise Exception(f"Launch Template '{self.name}' not found in AWS")

            lt = lts[0]

            self.ext["launch_template_id"] = lt.get("LaunchTemplateId")
            self.ext["launch_template_name"] = lt.get("LaunchTemplateName")
            self.ext["latest_version_number"] = lt.get("LatestVersionNumber")
            self.ext["default_version_number"] = lt.get("DefaultVersionNumber")
            self.ext["created_time"] = lt.get("CreateTime")

            print(
                f"Successfully fetched configuration for Launch Template: {self.name}"
            )
            return self

        def _resolve_launch_template_id(self) -> str:
            if self.ext.get("launch_template_id"):
                return self.ext["launch_template_id"]
            self.fetch()
            if not self.ext.get("launch_template_id"):
                raise Exception(
                    f"Failed to resolve Launch Template id for '{self.name}'"
                )
            return self.ext["launch_template_id"]

        def _resolve_image_id(self) -> str:
            if self.image_id:
                return self.image_id

            # Auto-resolve latest AL2023 ARM64 AMI for the current region
            from .native.configs import resolve_al2023_arm64_ami
            self.image_id = resolve_al2023_arm64_ami(self.region)
            return self.image_id

            if not self.image_builder_pipeline_name:
                return ""

            import boto3

            client = aws_client("imagebuilder", self.region, self.name)

            pipeline_arn = ""
            paginator = client.get_paginator("list_image_pipelines")
            for page in paginator.paginate():
                for item in page.get("imagePipelineList", []) or []:
                    if item.get(
                        "name"
                    ) == self.image_builder_pipeline_name and item.get("arn"):
                        pipeline_arn = item["arn"]
                        break
                if pipeline_arn:
                    break

            if not pipeline_arn:
                raise Exception(
                    f"Failed to resolve Image Builder pipeline ARN for '{self.image_builder_pipeline_name}'"
                )

            resp = client.list_image_pipeline_images(
                imagePipelineArn=pipeline_arn,
                maxResults=25,
            )
            images = resp.get("imageSummaryList", []) or []
            if not images:
                raise Exception(
                    f"No images found for Image Builder pipeline '{self.image_builder_pipeline_name}'"
                )

            images.sort(key=lambda s: s.get("dateCreated", "") or "", reverse=True)
            image_arn = images[0].get("arn", "")
            if not image_arn:
                raise Exception(
                    f"Failed to resolve latest image ARN for pipeline '{self.image_builder_pipeline_name}'"
                )

            image_resp = client.get_image(imageBuildVersionArn=image_arn)
            image = image_resp.get("image") or {}

            for output in image.get("outputResources", {}).get("amis", []) or []:
                if output.get("region") == self.region and output.get("image"):
                    self.image_id = output["image"]
                    return self.image_id

            for output in image.get("outputResources", {}).get("amis", []) or []:
                if output.get("image"):
                    self.image_id = output["image"]
                    return self.image_id

            raise Exception(
                f"Failed to resolve AMI id for pipeline '{self.image_builder_pipeline_name}'"
            )

        def _build_launch_template_data(self) -> Dict[str, Any]:
            if self.data:
                return self.data

            resolved_image_id = self._resolve_image_id()
            if not self.instance_type:
                raise ValueError(
                    f"instance_type must be set for Launch Template '{self.name}'"
                )

            lt_data: Dict[str, Any] = {
                "ImageId": resolved_image_id,
                "InstanceType": self.instance_type,
            }

            # Add mandatory runner identification tags to instances launched from this template
            tag_specs = []
            instance_tags = {"praktika_rn": self.name}
            # Add resource tag if specified
            if self.praktika_resource_tag:
                instance_tags["praktika_resource_tag"] = self.praktika_resource_tag
            if self.runner_type:
                instance_tags["github:runner-type"] = self.runner_type

            if instance_tags:
                tag_specs.append(
                    {
                        "ResourceType": "instance",
                        "Tags": [
                            {"Key": k, "Value": v} for k, v in instance_tags.items()
                        ],
                    }
                )
                lt_data["TagSpecifications"] = tag_specs

            sg_ids = list(self.security_group_ids)
            if self.security_group_names:
                ec2_lookup = aws_client("ec2", self.region, self.name)
                resp = ec2_lookup.describe_security_groups(Filters=[
                    {"Name": "group-name", "Values": self.security_group_names}
                ])
                resolved = {sg["GroupName"]: sg["GroupId"] for sg in resp["SecurityGroups"]}
                for name in self.security_group_names:
                    if name not in resolved:
                        raise ValueError(f"Security group '{name}' not found in region {self.region}")
                    sg_ids.append(resolved[name])
            if sg_ids:
                lt_data["SecurityGroupIds"] = sg_ids

            if self.iam_instance_profile_name:
                lt_data["IamInstanceProfile"] = {
                    "Name": self.iam_instance_profile_name,
                }

            if self.user_data:
                lt_data["UserData"] = base64.b64encode(
                    self.user_data.encode("utf-8")
                ).decode("utf-8")

            if self.block_device_mappings:
                lt_data["BlockDeviceMappings"] = self.block_device_mappings

            if self.tenancy:
                lt_data.setdefault("Placement", {})
                lt_data["Placement"]["Tenancy"] = self.tenancy

            if self.host_id:
                lt_data["Placement"] = {
                    "Tenancy": "host",
                    "HostId": self.host_id,
                }
                return lt_data

            return lt_data

        def _is_current_version_up_to_date(self, ec2, lt_id: str, desired: dict) -> bool:
            try:
                resp = ec2.describe_launch_template_versions(
                    LaunchTemplateId=lt_id, Versions=["$Latest"]
                )
                versions = resp.get("LaunchTemplateVersions", [])
                if not versions:
                    return False
                current = versions[0].get("LaunchTemplateData", {})
            except Exception:
                return False

            def _norm(data: dict) -> dict:
                out = {}
                for key in ("ImageId", "InstanceType"):
                    if key in data:
                        out[key] = data[key]
                # UserData: decode both sides before comparing — AWS may return
                # different base64 padding/line breaks than what we encoded.
                if "UserData" in desired:
                    def _decode(s):
                        try:
                            return base64.b64decode(s).decode("utf-8") if s else ""
                        except Exception:
                            return s
                    out["UserData"] = _decode(desired["UserData"])
                    out["_current_UserData"] = _decode(current.get("UserData", ""))
                # Security groups
                if "SecurityGroupIds" in desired:
                    out["SecurityGroupIds"] = sorted(desired["SecurityGroupIds"])
                    out["_current_SecurityGroupIds"] = sorted(
                        current.get("NetworkInterfaces", [{}])[0].get("Groups", [{}])
                        if current.get("NetworkInterfaces")
                        else current.get("SecurityGroupIds", [])
                    )
                # IAM profile: compare by name
                dp = desired.get("IamInstanceProfile", {})
                cp = current.get("IamInstanceProfile", {})
                if dp:
                    out["IamProfileName"] = dp.get("Name", "")
                    out["_current_IamProfileName"] = cp.get("Arn", "").split("/")[-1] if cp.get("Arn") else cp.get("Name", "")
                return out

            d = _norm(desired)
            for key, val in d.items():
                if key.startswith("_current_"):
                    continue
                current_val = d.get(f"_current_{key}", current.get(key))
                if key == "UserData":
                    current_val = d["_current_UserData"]
                if val != current_val:
                    print(f"  Launch Template field changed: {key}")
                    return False
            return True

        def deploy(self):
            """
            Create or update (create new version) an EC2 Launch Template.

            Notes:
                - This component expects `data` to be a valid EC2 LaunchTemplateData dict.
                - It intentionally does not attempt to diff/merge existing template data.
            """
            import boto3

            launch_template_data = self._build_launch_template_data()

            ec2 = aws_client("ec2", self.region, self.name)

            # Determine if LT exists
            exists = False
            try:
                self.fetch()
                exists = True
                print(
                    f"Fetched existing configuration for Launch Template: {self.name}"
                )
            except Exception:
                print(
                    f"Launch Template {self.name} does not exist yet, will create new"
                )

            if not exists:
                resp = ec2.create_launch_template(
                    LaunchTemplateName=self.name,
                    LaunchTemplateData=launch_template_data,
                )
                lt = resp.get("LaunchTemplate", {})
                self.ext["launch_template_id"] = lt.get("LaunchTemplateId")
                self.ext["latest_version_number"] = lt.get("LatestVersionNumber")
                self.ext["default_version_number"] = lt.get("DefaultVersionNumber")
                print(f"Successfully created Launch Template: {self.name}")
                return self

            # Exists — check if current version matches desired config
            if not self.create_new_version:
                raise ValueError(
                    f"Launch Template '{self.name}' already exists and create_new_version=False"
                )

            lt_id = self._resolve_launch_template_id()

            if self._is_current_version_up_to_date(ec2, lt_id, launch_template_data):
                print(f"Launch Template '{self.name}' is already up to date, skipping")
                self.ext["version_updated"] = False
                return self

            resp = ec2.create_launch_template_version(
                LaunchTemplateId=lt_id,
                LaunchTemplateData=launch_template_data,
            )

            version = resp.get("LaunchTemplateVersion", {})
            new_version_number: Optional[int] = version.get("VersionNumber")
            if new_version_number is not None:
                self.ext["latest_version_number"] = new_version_number

            if self.set_default_version_to_latest and new_version_number is not None:
                ec2.modify_launch_template(
                    LaunchTemplateId=lt_id,
                    DefaultVersion=str(new_version_number),
                )
                self.ext["default_version_number"] = new_version_number

            self.ext["version_updated"] = True
            print(
                f"Successfully created new version for Launch Template: {self.name} (version={new_version_number})"
            )
            return self

        def delete(self):
            import boto3
            client = aws_client("ec2", self.region, self.name)
            try:
                client.delete_launch_template(LaunchTemplateName=self.name)
                print(f"Deleted Launch Template '{self.name}'")
            except client.exceptions.ClientError as e:
                if "does not exist" in str(e).lower() or "InvalidLaunchTemplateName" in str(e):
                    print(f"Launch Template '{self.name}' does not exist, skipping")
                else:
                    raise
