import time

import requests

try:
    import jwt  # From pyjwt

    assert hasattr(jwt, "encode"), "Invalid jwt module, 'encode' not found"
    USING_PYJWT = True
except (ImportError, AssertionError):
    USING_PYJWT = False
    print(
        "Warning: pyjwt not available. Falling back to 'jwt' module (not recommended)"
    )
    from jwt import jwk_from_pem, JWT

from praktika.utils import Shell


class GHAuth:

    @classmethod
    def _get_access_token_by_jwt(cls, jwt_token: str, installation_id: int) -> str:
        headers = {
            "Authorization": f"Bearer {jwt_token}",
            "Accept": "application/vnd.github.v3+json",
        }
        response = requests.post(
            f"https://api.github.com/app/installations/{installation_id}/access_tokens",
            headers=headers,
            timeout=10,
        )
        response.raise_for_status()
        token = response.json()["token"]  # type: str
        return token

    @classmethod
    def _get_access_token(cls, private_key: str, app_id: str, installation_id: int) -> str:
        payload = {
            "iat": int(time.time()) - 60,
            "exp": int(time.time()) + (10 * 60),
            "iss": app_id,
        }

        jwt_instance = jwt.PyJWT()
        encoded_jwt = jwt_instance.encode(payload, private_key, algorithm="RS256")
        return cls._get_access_token_by_jwt(encoded_jwt, installation_id)

    @classmethod
    def _get_access_token_deprecated(cls, app_key, app_id, installation_id: int):
        def _generate_jwt(client_id, pem):
            pem = str.encode(pem)
            signing_key = jwk_from_pem(pem)
            payload = {
                "iat": int(time.time()),
                "exp": int(time.time()) + 600,
                "iss": client_id,
            }
            # Create JWT
            jwt_instance = JWT()
            encoded_jwt = jwt_instance.encode(payload, signing_key, alg="RS256")
            return encoded_jwt

        jwt_token = _generate_jwt(app_id, app_key)
        return cls._get_access_token_by_jwt(jwt_token, installation_id)

    @classmethod
    def auth(cls, app_id, app_key, installation_id: int) -> None:
        if USING_PYJWT:
            access_token = cls._get_access_token(app_key, app_id, installation_id)
        else:
            access_token = cls._get_access_token_deprecated(app_key, app_id, installation_id)
        Shell.check(f"echo {access_token} | gh auth login --with-token", strict=True)

    @classmethod
    def get_installation_token(cls) -> str:
        """Return a raw GitHub App installation access token."""
        from praktika.secret import Secret
        from praktika.settings import Settings

        app_id, pem, installation_id = Secret.Config(
            name=[
                f"{Settings.SECRET_GH_APP}.app-id",
                f"{Settings.SECRET_GH_APP}.app-key",
                f"{Settings.SECRET_GH_APP}.app-installation-id",
            ],
            type=Secret.Type.AWS_SSM_SECRET,
            region=Settings.AWS_REGION,
        ).get_value()
        return cls._get_access_token(pem, app_id, int(installation_id))

    @classmethod
    def auth_from_settings(cls) -> None:
        Shell.check(f"echo {cls.get_installation_token()} | gh auth login --with-token", strict=True)


# if __name__ == "__main__":
#     from praktika.secret import Secret
#
#     pem = Secret.Config(
#         name="woolenwolf_gh_app.clickhouse-app-key",
#         type=Secret.Type.AWS_SSM_SECRET,
#     ).get_value()
#     app_id = Secret.Config(
#         name="woolenwolf_gh_app.clickhouse-app-id",
#         type=Secret.Type.AWS_SSM_SECRET,
#     ).get_value()
#     print(app_id, pem)
#     GHAuth.auth(app_id, pem)
